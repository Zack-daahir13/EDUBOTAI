from django.shortcuts import render
import cohere


co = cohere.Client(
    api_key = 'ExfyzmxVkspA1mZgff7bBRj1pI5DGo38NGsOSlo3'
)



def get_data(request):
    
    title = 'Data Form'
    
    context = {
        'title' : title
    }
    
    if request.method == 'POST':
        name = request.POST.get('name')
        subjects = request.POST.getlist('subjects')
        favorite_subject = request.POST.get('favorite_subject')
        
        response = co.chat(
            message = f"Hi, my name is {name}, I live these subjects {subjects} and my favorite subject is {favorite_subject}, I want you to consult me on what faculty to choose for my university degree"
        )
        
        message = response.text
        
        context = {
            'name': name,
            'subjects': subjects,
            'favorite_subject': favorite_subject,
            'message': message
        }
        
    
    return render(request, 'bot/form.html', context)