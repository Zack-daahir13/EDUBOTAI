# EDU BOT

## Installation Guide

### Virtual Environment Setup

```bash
python -m venv venv
venv\Scripts\activate

pip install -r requirements.txt
```

```bash

python manage.py runserver
```
